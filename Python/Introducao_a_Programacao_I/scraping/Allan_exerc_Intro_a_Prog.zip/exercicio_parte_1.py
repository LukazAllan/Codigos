# Author: Allan Lucas
# Python 3.6+
# Dependencies: urllib, requests-html os
from urllib.request import urlopen as upen
from requests_html import HTML
import os.path as path


site = 'https://precodoscombustiveis.com.br/pt-br/city/brasil/paraiba/joao-pessoa/1335'
with upen(site) as resp:
    #resp.code = {200: 'OK', 400: 'bad request', 403: 'forbidden', 404: "not found"}
    resposta = resp.code
    if resposta == 200:
        print('Conectado com sucesso!')
    else:
        print('Veja se estás realmente conectado à internet!')
    data = resp.read()
html = HTML(html=data.decode('UTF-8'))
valor = dict()
for c in (
    ('div.card:nth-child(2) > div:nth-child(1) > span:nth-child(5)', 'gasolina'),
    ('div.card:nth-child(3) > div:nth-child(1) > span:nth-child(5)','etanol')
    ):
    pesquisa = html.find(c[0])
    valor[c[1]] = int(pesquisa[0].text[3:].replace('.',''))/1000

if valor['gasolina'] > valor['etanol']:
    print(f"Na cidade de João Pessoa, é mais barato comprar Gasolina a R${valor['gasolina']}, que Etanol a R${valor['etanol']}")
elif valor['gasolina'] < valor['etanol']:
    print(f"Na cidade de João Pessoa, é mais barato comprar Etanol a R${valor['etanol']}, que Gasolina a R${valor['gasolina']}")
else:
    print(f"Na cidade de João Pessoa, não faz diferença comprar Gasolina e Etanol ambos a R${valor['gasolina']}")
