# Author: Allan Lucas
# Python 3.6+
# Dependencies: urllib, requests-html os
from urllib.request import urlopen as upen
import urllib
from requests_html import HTML
import os.path as path


site = 'https://precodoscombustiveis.com.br/pt-br/city/brasil/paraiba/joao-pessoa/1335'
try:
    with upen(site) as resp:
        #resp.code = {200: 'OK', 400: 'bad request', 403: 'forbidden', 404: "not found"}
        resposta = resp.code
        if resposta == 200:
            print('Conectado com sucesso!')
        else:
            print('Veja se estás realmente conectado à internet!')
        data = resp.read()
except TimeoutError or URLError:
    print('Servidor demorou para responder, tente de novo.')
else:
    html = HTML(html=data.decode('UTF-8'))
    valor = dict()
    for c in (
        ('div.card:nth-child(2) > div:nth-child(1) > span:nth-child(5)', 'gasolina'),
        ('div.card:nth-child(3) > div:nth-child(1) > span:nth-child(5)','etanol')
        ):
        pesquisa = html.find(c[0])
        valor[c[1]] = int(pesquisa[0].text[3:].replace('.',''))/1000

    cap_max = float(input('Para valores com virgula, use ponto.\nQuanto e a capacidade maxima do seu veiculo, em litros: '))
    km_l = {
        'gasolina':float(input('Com quantos quilometros de Gasolina seu veiculo anda por litro? ')),
        'etanol':float(input('Com quantos quilometros de Etanol seu veiculo anda por litro? '))
    }
    auto = {
        'gasolina':cap_max*km_l['gasolina'],
        'etanol':cap_max*km_l['etanol']
    }
    distancia = 764
    print(cap_max, km_l, auto)
    print(f"""
Numa viagem entre João Pessoa e Salvador, de {distancia}km

Usando Gasolina em toda a viagem, se começar a viagem com o tanque cheio:
você vai parar {int((distancia-auto['gasolina'])/auto['gasolina'])} vezes para abastecer.
Gastará em média: R${int((distancia-auto['gasolina'])/auto['gasolina'])*valor['gasolina']*cap_max:.2f}

Usando Etanol em toda a viagem, se começar a viagem com o tanque cheio:
você vai parar {int((distancia-auto['etanol'])/auto['etanol'])} vezes para abastecer.
Gastará em média: R${int((distancia-auto['etanol'])/auto['etanol'])*valor['etanol']*cap_max:.2f}
""")


